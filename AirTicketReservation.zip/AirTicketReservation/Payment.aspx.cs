﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AirTicketReservation
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            String from = Request.Form["From"];
            String TO = Request.Form["To"];
            String Time = Request.Form["Time"];
            String Money = Request.Form["email"];
            String User = Request.Form["price"];
            String Date = "12/05/2017";
            Random rnd = new Random();
            String Sit = rnd.Next(40000, 60000).ToString();
            String ID = Request.Form["ID"];

            String UserEmail = "NNNN";
            if (Session["Email"] != null)
            {

                UserEmail = Session["Email"].ToString();


            }




            String SQL = "Insert into Booking (AirLineID, UserID, FromM, ToM, DateM, Time, SitNo, Adult, Child, Payment) Values ('"+ID+"','"+UserEmail+"','"+from+"','"+TO+"','"+Date+"','"+Time+"','"+Sit+"','"+Money+"','Paid','ffff')";
            HelperClass.executeQuery(SQL);

           



        }
    }
}