﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AirTicketReservation
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String Email = Request.Form["email"];
            String Passwrod = Request.Form["password"];

            bool flag = new HelperClass().userLogin(Email, Passwrod);
            if (flag)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                Response.Redirect("Default.aspx?LoginFailed=True");
            }
        }
    }
}