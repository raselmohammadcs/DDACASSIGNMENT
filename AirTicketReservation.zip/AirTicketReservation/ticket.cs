﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirTicketReservation
{
    public class ticket
    {

        private int Id;
        private String AirID;
        private string UserID;
        private string From;
        private string TO;
        private string Date;
        private string Time;
        private string SitNo;
        private string Audult;
        private string Child;
        private string Payment;


        public ticket(String AirID,string UserID, string From, string TO, string Date, string Time, string SitNo, string Audult, string Child, string Payment)
        {
            this.AirID = UserID;
            this.UserID = UserID;
            this.From = From;
            this.TO = TO;
            this.Date = Date;
            this.Time = Time;
            this.SitNo = SitNo;
            this.Audult = Audult;
            this.Child = Child;
            this.Payment = Payment;
        }


        public int Id1
        {
            get
            {
                return Id;
            }

            set
            {
                Id = value;
            }
        }

        public string AirID1
        {
            get
            {
                return AirID;
            }

            set
            {
                AirID = value;
            }
        }

        public string UserID1
        {
            get
            {
                return UserID;
            }

            set
            {
                UserID = value;
            }
        }

        public string From1
        {
            get
            {
                return From;
            }

            set
            {
                From = value;
            }
        }

        public string TO1
        {
            get
            {
                return TO;
            }

            set
            {
                TO = value;
            }
        }

        public string Date1
        {
            get
            {
                return Date;
            }

            set
            {
                Date = value;
            }
        }

        public string Time1
        {
            get
            {
                return Time;
            }

            set
            {
                Time = value;
            }
        }

        public string SitNo1
        {
            get
            {
                return SitNo;
            }

            set
            {
                SitNo = value;
            }
        }

        public string Audult1
        {
            get
            {
                return Audult;
            }

            set
            {
                Audult = value;
            }
        }

        public string Child1
        {
            get
            {
                return Child;
            }

            set
            {
                Child = value;
            }
        }

        public string Payment1
        {
            get
            {
                return Payment;
            }

            set
            {
                Payment = value;
            }
        }
    }
}