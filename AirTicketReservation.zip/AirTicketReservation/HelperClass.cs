﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace AirTicketReservation
{
    public class HelperClass
    {

        public static SqlConnection getConnection() 
        {
            SqlConnection conn = null;

                String url = "";
            conn = new SqlConnection(@"Data Source=ukairlinesdatabaseserver.database.windows.net;Initial Catalog=AirLineReservation;Integrated Security=False;User ID=raselmohammad;Password=Ukairlines@1994;Connect Timeout=60;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        return conn;
        }

        public static void executeQuery(String strQuery) 
        {


            SqlConnection conn = getConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(strQuery, conn);
            cmd.ExecuteNonQuery();
            closeConnection(conn);

        }

        public static void closeConnection(SqlConnection conn)
        {
            
                if (conn.State ==ConnectionState.Open)
                {
                conn.Close();
                }
            
        }


        public bool registerUser(Users user)
        {
            executeQuery("Insert into Users (FirstName, LastName, Email, Password, Contact, Address, Birthday) values ('"+user.FirstName1+"','"+user.LastName1+"','"+user.Email+"','"+user.Password1+"','"+user.Contact+"','"+user.Address1+"','"+user.Contact+"')");
            return true;
        }


        public bool userLogin(String email, String password)
        {
            String query = "Select Email, Password from users where Email = '"+email+"' and Password = '"+password+"'";
            SqlConnection conn = getConnection();
            SqlCommand cm = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cm);
            sda.Fill(dt);
            conn.Open();

            int i = cm.ExecuteNonQuery();
            closeConnection(conn);
            bool flag = false;

            if (dt.Rows.Count > 0)
            {
              System.Web.HttpContext.Current.Session["Email"] = email;
                flag = true;
            }

            
            return flag;
        }


        public List<Airline> airLineList(String param)
        {
            String query = "Select * from AirLine";
            SqlConnection conn = HelperClass.getConnection();
            SqlCommand cm = new SqlCommand(query, conn);
            conn.Open();

            SqlDataReader sdr = cm.ExecuteReader();
            List<Airline> air = new List<Airline>();

            while (sdr.Read())
            {
                Airline ar = new Airline(Convert.ToInt32(sdr["Id"].ToString()), sdr["Name"].ToString(), sdr["duration"].ToString(), sdr["Price"].ToString(), sdr["Image"].ToString(), sdr["FromN"].ToString(), sdr["ToN"].ToString());
                air.Add(ar);
            }

            return air;
        }
    }
}