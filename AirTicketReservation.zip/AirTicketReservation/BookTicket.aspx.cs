﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;

namespace AirTicketReservation
{
    public partial class BookTicket : System.Web.UI.Page
    {

        
        protected void Page_Load(object sender, EventArgs e)
        {

            String to = Request.Form["children14"];
            String From = Request.Form["children7"];



            List<Airline> air = new HelperClass().airLineList(to);
            StringBuilder sb = new StringBuilder();
            foreach (Airline a in air)
            {



                sb.Append("<div class='col-lg-4 col-sm-4 col-sm-4'>");
                sb.Append("<figure>");
                sb.Append("<div class='cbp-vm-image img'>");
                sb.Append("<form method='post' action='Payment.aspx?PlaneID=" + a.Id1 + "'>");
                sb.Append("<img src ='images/fly/1.png' alt='img01' />");
                sb.Append("<figcaption>");


                sb.Append("<input type ='hidden' name =' From' value='" + From + "' />");
                sb.Append("<input type ='hidden' name =' To' value='" + to + "' />");
                sb.Append("<input type ='hidden' name =' Time' value='06:10' />");
                sb.Append("<input type ='hidden' name =' price' value='$" + a.Price1 + "' />");
                sb.Append("<input type ='hidden' name ='ID ' value='" + a.Id1 + "' />");




                sb.Append("<h3>FR 000"+a.Id1+"</h3>");
                sb.Append("<span style='color:red;'>" + From+ "</span> <span style='color:red;'>" + to + "</span><div class='clear'></div>");
                sb.Append("<span style='color:red;'>06:10</span> <span style='color:red;'>10:30</span><span style='color:red;'><i class='fa fa-clock-o'></i>" + a.Duration+ "</span>");
                sb.Append("<div class='clear'></div>");
                sb.Append("<div class='price-night'><span>1 Stop</span><span class='price-n'>$" + a.Price1 + "</span></div>");
                sb.Append("<button type='submit'  class='btn btn-primary btn-gallery'>Buy Now</button>");
                sb.Append("</figcaption>");
                sb.Append("</form>");
                sb.Append("  </figure></div>");

            }


            g.InnerHtml = sb.ToString();
    }
    }
}



 //<div class="cbp-vm-image img">
 //                                           <img src = "images/fly/1.png" alt="img01" />
 //                                       </div>

 //                                       <figcaption>
 //                                           <h3>FR 6341</h3>
 //                                           <span>Dublin</span> <span>Lanzarote</span><div class="clear"></div>
 //                                           <span>06:10</span> <span>10:30</span><span><i class="fa fa-clock-o"></i>4 h 20 min</span>
 //                                           <div class="clear"></div>
 //                                           <div class="price-night"><span>1 Stop</span><span class="price-n">$1250</span></div>
 //                                           <a href = "#" class="btn btn-primary btn-gallery">Buy Now</a>
 //                                         </figcaption>