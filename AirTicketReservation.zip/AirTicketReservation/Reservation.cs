﻿namespace AirTicketReservation
{
    internal class Reservation
    {
    }
}