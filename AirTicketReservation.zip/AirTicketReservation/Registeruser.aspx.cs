﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AirTicketReservation
{
    public partial class Registeruser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String FName  = Request.Form["Firstname"];
            String LName = Request.Form["lastname"];
            String Email = Request.Form["email"];
            String Passsword = Request.Form["password"];
            String Contact = Request.Form["contact"];
            String Address = Request.Form["address"];
            String Birthday = Request.Form["bday"];

            Users u = new Users(FName, LName, Email, Passsword, Contact, Address, Birthday);
            new HelperClass().registerUser(u);
            Response.Redirect("Default.aspx?RegisterStatus=True");
        }
    }
}