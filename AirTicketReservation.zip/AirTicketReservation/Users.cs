﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirTicketReservation
{
    public class Users
    {
        private int id;
        private String FirstName;
        private String LastName;
        private String email;
        private String Password;
        private String contact;
        private String Address;
        private String birthday;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string FirstName1
        {
            get
            {
                return FirstName;
            }

            set
            {
                FirstName = value;
            }
        }

        public string LastName1
        {
            get
            {
                return LastName;
            }

            set
            {
                LastName = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Password1
        {
            get
            {
                return Password;
            }

            set
            {
                Password = value;
            }
        }

        public string Contact
        {
            get
            {
                return contact;
            }

            set
            {
                contact = value;
            }
        }

        public string Address1
        {
            get
            {
                return Address;
            }

            set
            {
                Address = value;
            }
        }

        public string Birthday
        {
            get
            {
                return birthday;
            }

            set
            {
                birthday = value;
            }
        }

        public Users(string firstName, string lastName, string email, string password, string contact, string address, string birthday)
        {
            FirstName = firstName;
            LastName = lastName;
            this.email = email;
            Password = password;
            this.contact = contact;
            Address = address;
            this.birthday = birthday;
        }



    }
}