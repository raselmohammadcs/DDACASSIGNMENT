﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;


namespace AirTicketReservation
{
    public partial class ViewTicket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["Email"] != null) { 
            String UserEmail = Session["Email"].ToString();

            StringBuilder sb = new StringBuilder();


            String query = "Select * from Booking Where UserID = '"+UserEmail+"'";
            SqlConnection conn = HelperClass.getConnection();
            SqlCommand cm = new SqlCommand(query, conn);
            conn.Open();

            SqlDataReader sdr = cm.ExecuteReader();



            while (sdr.Read())
            {

                sb.Append("<tr>");
                sb.Append("<td>"+ sdr["Id"].ToString() + "</td>");
                sb.Append("<td>" + sdr["AirLineID"].ToString() + " </td>");
                sb.Append("<td>" + sdr["UserID"].ToString() + " </td>");
                sb.Append("<td>" + sdr["FromM"].ToString() + " </td>");
                sb.Append("<td>" + sdr["ToM"].ToString() + " </td>");
                sb.Append("<td>" + sdr["DateM"].ToString() + " </td>");
                sb.Append("<td>" + sdr["Time"].ToString() + " </td>");
                sb.Append("<td>" + sdr["SitNo"].ToString() + " </td>");
                sb.Append("<td>" + sdr["Adult"].ToString() + " </td>");
                sb.Append("<td>" + sdr["Child"].ToString() + " </td>");
                sb.Append("<td>" + sdr["Payment"].ToString() + " </td>");
                sb.Append("</tr>");
            }


            tobdy.InnerHtml = sb.ToString();

        }
        }
    }
}