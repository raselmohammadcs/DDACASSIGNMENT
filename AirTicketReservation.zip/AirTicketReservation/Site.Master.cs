﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AirTicketReservation
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["LoginFailed"] != null)
            {
                String loginStatus = Request.QueryString["LoginFailed"].ToString();
                if (loginStatus.Equals("True"))
                {
                    Response.Write("<script>alert('SORRY!! Invalid Login.....');</script>");
                }
            }


            if (Request.QueryString["RegisterStatus"] != null)
            {
                String RegisterSattus = Request.QueryString["RegisterStatus"].ToString();
                if (RegisterSattus.Equals("True"))
                {
                    Response.Write("<script>alert('Registration Successful !! Please Login');</script>");
                }
            }

            
        }
    }
}