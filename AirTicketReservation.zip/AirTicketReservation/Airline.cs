﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirTicketReservation
{
	public class Airline
	{

        private int Id;
        private string Name;
        private string duration;
        private string Price;
        private string Image;
        private string From;
        private string To;



        public Airline(int ID, string Name, string duration, string Price, string Image, string fromm, string to0)
        {
            this.Id = ID;
            this.Name = Name;
            this.duration = duration;
            this.Price = Price;
            this.Image = Image;
            this.From = fromm;
            this.To = to0;

        }

        public int Id1
        {
            get
            {
                return Id;
            }

            set
            {
                Id = value;
            }
        }

        public string Name1
        {
            get
            {
                return Name;
            }

            set
            {
                Name = value;
            }
        }

        public string Duration
        {
            get
            {
                return duration;
            }

            set
            {
                duration = value;
            }
        }

        public string Price1
        {
            get
            {
                return Price;
            }

            set
            {
                Price = value;
            }
        }

        public string Image1
        {
            get
            {
                return Image;
            }

            set
            {
                Image = value;
            }
        }

        public string From1
        {
            get
            {
                return From;
            }

            set
            {
                From = value;
            }
        }

        public string To1
        {
            get
            {
                return To;
            }

            set
            {
                To = value;
            }
        }
    }
}